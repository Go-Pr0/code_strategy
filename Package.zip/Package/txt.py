#================================================================================================#
#QUESTIONS
#================================================================================================#
x = """
MARKETS

BTC (1)
TOTAL3 (2)
ALT DOM (3)

"""

xx = """
MARKET ENVIRONMENTS

Uptrend (1)
Downtrend (2)
Range (3)
Chop (4)

"""

xx_d = """
MARKET ENVIRONMENTS

Uptrend (1)
Downtrend (2)
Range (3)

"""

a = """
Regular Uptrend (1)
Frothy or Parabolic Uptrend (2)
Structural Buying (3)
HTF breakout (4)

"""

ba = """
Downtrend (1)
Late downtrend (2) -> very far from ATHs + heavily shorted already
Post Nuke (3) -> Big gap in price and 4H trend after massive nuke
Structural Selling (4)
HTF breakdown (5)

"""

ca = """
Accumelation ranges (1) -> base building
Distribution ranges (2) -> rounded top/bottom range magnet
Ranges (3) -> Regular old range

"""

#--



#================================================================================================#
#ENDS
#================================================================================================#

# BTC
# UPTRENDS

aaa = """ 

--------------------------------



BTC UPTRENDS

Use BTC.D to spot relative strength

Considering this is a regular uptrend, in a larger range or not:
- Taking positions via:
    > 4H trend
    > 4H 200s


MANAGEMENT
- Derisking
    > See past trends
    > Levels
    ...
- Regular size

"""

aab = """ 

--------------------------------



FROTHY BTC UPTRENDS

Think of markets like gears, start at first and build itself up towards this market environment, shift into 5th before this parabolic ssn has started and start downshifting as you approach the top.

- Large gap between:
    > 4H trend
    > D1 trend
- Euphoric timeline
- Alt OI > BTC OI (derisk signal)

SETUPS
- 4H 200s
- 1H 200s
+ S/R LEVEL

MANAGEMENT
- Derisking:
    > As we approach HTF resistance (-> or psychological levels)
    > 4H trend losses
- No new positions at current pricing
- Healthy spot/leverage ratio
- Wide SL on stinkbids

HEDGING
- Sell HTF levels
    > Low leverage
    > Wide stops

"""

aac = """

--------------------------------



BTC STRUCTURAL BUYING

This often traps a lot of ppl, especially structured buying into resistance, aka vertical consolidation.

2 Main scenarios:

- POST NUKE
    > Bottoming pattern
    > 'Free shorts'
    > Squeeze
- EUPHORIA
    > Upside?

Look at the context, strucural buying can be confused with an unsustainable grind up, make sure to know what it is you're looking at.

MANAGEMENT
- Targets
    > S/R levels
    > Gapfills
- SL at discretion


"""

aae = """

--------------------------------



HTF BTC BREAKOUTS

Early?
- Bid 4H trend OR a breakout

Too late for a breakout?
- Bid first shallow pullbacks into 4H trend with conviction

Nearing the end? -> See frothy btc uptrend
- Stinkbids at 1H 200s
- Stinkbids at 4H 200s
(depending on the situation)

EXCECUTION
- Large size (for option 1 & 2 )

MANAGEMENT
- TPing
    > Near HTF levels
    > Breaks of structure

"""

#DOWNTRENDS

baa = """

--------------------------------



BTC DOWNTRENDS

- Evalutation
    > Is BTC the asset worth shorting here?

IF SO
- Entry:
    > 4H 200
    > Resistance

MANAGEMENT
- TPing
    > Support

Usually you don't want to be short BTC.

"""

bab = """

--------------------------------



LATE BTC DOWNTRENDS

- Large gap between:
    > 4H trend
    > D1 trend
- Inverted chart = parabolic

- Positioning
    > No new positions
    > No free shorts

MANAGEMENT
- Derisking:
    > Taps of support
    > Trend changes
    > ...
- Too good not to take?
    > TP quickly

"""

bac = """

--------------------------------



BTC POST NUKE

Post-nuke plays often take days to form, hours to play out

Look for gaps in price and EMA's:
- Mean reversion plays via:
    > Bottoming patterns
    > Reclaims of key levels
    > Bullish market structures - higher lows after continued lower lows
    > Reclaims of moving averages
    > ...

POSITIONING
- Pre-move up (-> doesn't have to be fully sized yet)
    > At key level
- LTF entry
    > 1H/30/15 trend reclaims
    > Local structure reclaims
- 4H trend reclaims 

(use the above to add to position as well)

HEDGING -> Only when expecting a shift in trend / downtrend
- Look at resistance levels to bounce off of
    > Sell the resistance
    > Sell 4H 200

MANAGEMENT
- Prepare for quick moves, chop = worst case

"""

bad = """

--------------------------------



STRUCTURAL BTC SELLING

Usually:
- Don't long this PA
- Results in final flush down -> Post Nuke

POSITIONING
- Don't take longs into this if you can avoid it
- Look at context, structural selling post nuke is different than mid range

MANAGEMENT
- Derisk longs if you have them still open
- Prepare for post nuke scenarios

"""

bae = """

--------------------------------



HTF BTC BREAKDOWN

This usually folllows after a distribution range/top pattern
Use BTC.D & ALT/BTC charts (-> If on Binance)

Ask yourself
- Is it worth it to short BTC here?
* If YES:
    > Swing short positions alongside 4H 200s  
* If NO:
    > Move onto alts

MANAGEMENT
- Close longs
- Sell spot
- Wait for possible base building
- Extend targets on shorts

"""

#RANGES

caa = """

--------------------------------



BTC ACCUMULATION RANGES - BASE BUILDING

Can form in many ways:
- Compression into the lows (max pain)
- Rounded bottoms
- ...

POSITIONING
- Mostly long
- In anticipation of a move up
- 4H 200 reclaims

MANAGEMENT
- Targets:
    > Range highs
    > Beyond range highs (if the time is right)
- Regular management

"""

cab = """

--------------------------------



BTC DISTRIBUTION RANGES - TOPS

Can form in many ways:
- Rounded tops
- Fakeouts (most common)
- ...

- Pre top signal:
    > Position as usual
    > See Frothy BTC Uptrends

- Post top signal:
    > Derisk longs
    > Look at Early BTC Downtrends

POSITIONING
- Easy on leverage
- Smaller size than early uptrend

Note that BTC is usually not the asset you want to be short, look at ALT/BTC charts and short underperfomers.

"""

cac = """

--------------------------------



BTC RANGES

Large ranges:
- Long PA inside the range:
    > Bottoming patterns
    > Reclaims
    > ...
- Look at past trends

Consolidation ranges:
- Look at the current trend

Deviation plays:
- Deviation -> retest deviated level
    > Long or short
    > Normal management
- Invalidation on reclaim of the level

MANAGEMENT
- Target the most recent swing high/low inside the range or;
- Target range highs/lows

"""

#CHOPS

da = """

--------------------------------



CHOP

No trades, study past PA and prepare for upcoming/anticipated moves later on.

"""

#================================================================#
#TOTAL3
#================================================================#

aaa_1 = """

--------------------------------



ALTCOIN UPTRENDS


- Expect it to hold 4H trend most of the time, 

POSITIONING
- Long support 
- Long 4H 200
- Long 4H trend

MANAGEMENT
- Derisking
    > TOTAL3 HTF resistance
    > Local resistance (coin you're trading)
- TOTAL3 = confluence
-> Doesn't mean you should ALWAYS using this chart, example:

  ALT uptrend + broken out from a large range,
  TOTAL3 down & lost 4H trend causing that alt to retrace, 
  should u not long just bc total3 is pulling back? 
  No, expect a bounce and play it on that outperforming alt.

"""

aab_1 = """

--------------------------------



FROTHY ALTCOIN UPTRENDS

Think of markets like gears, start at first and build itself up towards this market environment, shift into 5th before this parabolic ssn has started and start downshifting as you approach the top. 

- Large gap between:
    - 4H trend
    - D1 trend
- Alt OI > BTC OI 

POSITIONING
- Lower size vs early uptrend
- Fewer positions

MANAGEMENT
- Derisk as we approach HTF resistance, image = prime example
- Derisk positions on 4H trend losses of TOTAL3
- Go easy on leverage & prefer spot
- Prep for nukes/leverage shakeouts

"""

aac_1 = """

--------------------------------



STRUCTURAL ALTCOIN BUYING

2 Main scenarios:

- POST NUKE
    > Bottoming pattern
    > 'Free shorts'
    > Squeeze
- EUPHORIA
    > Upside?

Look aat context, structural buying ≠ unsustainable grind up

MANAGEMENT
- Targets
    > S/R levels
    > Gapfills
- SL at discretion

"""

aad_1 = """

--------------------------------



HTF ALTCOIN BREAKOUTS

Early? (1)
- Bid 4H trend OR a breakout

Too late for a breakout? (2)
- Bid first shallow pullbacks into 4H trend with conviction
    > on the strongest alt

Nearing the end? -> See frothy altcoin uptrend (3)
- Stinkbids at 1H 200s
- Stinkbids at 4H 200s
(depending on the situation, all on the strongest alt)

See ALT/BTC charts available on Binance for outperformance

EXCECUTION
- Larger size (for option 1 & 2 )

MANAGEMENT
- TPing
    > Near HTF levels
    > Breaks of structure

"""

#DOWNTRENDS
baa_1 = """

--------------------------------



ALTCOIN DOWNTRENDS

TOTAL3 > 4H 200
ALT/BTC charts on Binance for confluence

POSITIONING
- Altcoins
- Short
- 4H 200
- S/R levels

MANAGEMENT
- Derisking
    > TOTAL3 HTF level
    > Local level
- Regular management

"""

bab_1 = """

--------------------------------



LATE ALTCOIN DOWNTRENDS

- Large gap between:
    > 4H trend
    > D1 trend
- Inverted chart = parabolic

POSITIONING
    > Fewer positions
    > Only the cleanest setups
    > 4H 200

MANAGEMENT
- Derisking
    > Taps of HTF support TOTAL3
    > Local Levels
    > Trend changes
    > Quick TPing
    > ...
- No free shorts

"""

bac_1 = """

--------------------------------



ALTCOINS POST NUKE

Post-nuke plays often take days to form, hours to play out.

- Leverage wipe
- Large gaps in price vs EMA's

- Mean reversion plays via:
    > Bottoming patterns
    > Reclaims of key levels
    > Bullish market structures - higher lows after continued lower lows
    > Reclaims of moving averages
    > ...
- ALT/BTC charts on Binance for outperformance

MANAGEMENT
- Prepare for quick moves, chop = worst case
- Exit if it doesn't go anywhere

SHORTS -> Only when expecting a shift in trend / downtrending 
- Look at resistance levels to bounce off of post pattern
    > Sell the resistance + 4H 200 -> DEADLY COMBO

"""

bad_1 = """

--------------------------------



STRUCTURAL ALTCOIN SELLING

Usually:
- Don't long this PA
- Results in final flush down -> Post Nuke

POSITIONING
- Don't take longs into this if you can avoid it
- Look at context, structural selling post nuke is different than mid range

MANAGEMENT
- Derisk longs if you have them still open
- Prepare for post nuke scenarios if necessary

"""

bae_1 = """

--------------------------------



HTF ALTCOIN BREAKDOWN

This usually folllows after a distribution range/top pattern
Use BTC.D & ALT/BTC charts (-> If on Binance)

POSITIONING
- If BTC > 4H 200: (leverage shakeout)
    > Easy on alts
    > Focus on BTC
    > Lower leverage
    > Only the strongest coins long

- If BTC < 4H 200:
    > Short
    > 4H 200 TOTAL3/Local
    > Resistance levels on TOTAL3/Local
    > ...

MANAGEMENT
- Close longs
- Sell spot
- Wait for possible base building
- Extend targets on shorts

ANTICIPATION
- Base building lower

"""

#RANGES
caa_1 = """

--------------------------------



ALTCOIN ACCUMULATION RANGES

Can form in many ways:
- Compression into the lows (max pain)
- Rounded bottoms
- After a top
- ...

POSITIONING
- Mostly long
- In anticipation of a move up
- 4H 200 reclaims

MANAGEMENT
- Targets:
    > Range highs
    > Beyond range highs (if the time is right)
- Regular management


"""

cab_1 = """

--------------------------------



DISTRIBUTION RANGES - TOPS

Can form in many ways:
- Rounded tops
- Fakeouts (most common)
- Post euphoria
- ...

- Pre top signal:
    > Position as usual
    > See Frothy Altcoin Uptrends

- Post top signal:
    > Derisk longs
    > Look at Early Altcoin Downtrends 

- Post top signal + breakdown:
    > Look at HTF breakdowns

POSITIONING
- Easy on leverage
- Smaller size than early uptrend


"""

cac_1 = """

--------------------------------



RANGES

Large ranges:
- Long PA inside the range:
    > Bottoming patterns
    > Reclaims
    > ...
- Look at past trends

Consolidation ranges:
- Look at the current trend

Deviation plays:
- Deviation -> retest deviated level
    > Long or short
    > Normal management
- Invalidation on reclaim of the level

Use ALT/BTC on Binance for confluence

MANAGEMENT
- Target the most recent swing high/low inside the range or;
- Target range highs/low
  
"""

# BTC DOM

aaa_2 = """

--------------------------------



UPTRENDS

Considering that you're in a real uptrend, you can expect a real cycle of alts outperforming btc. (Last time that happened was in 2021)

- Long outperforming alts but don't just look at ALT/BTC charts, try and find outperformance vs other strong alts
- Long pullbacks into 4H trend/4H 200s

MANAGEMENT
- Derisk when parabolic and nearing HTF support
(But make sure not to close too soon, btc.d runs are often straight up all the way not caring about resistance)

"""

baa_2 = """

--------------------------------



DOWNTRENDS

If you're still in in the massive downtrend BTC.D is currently in:

- Long on pullbacks into a higher timeframe trend post nuke (gapfills)
- Long BTC post gapfill (considering you're uptrending on BTC and have a setup)

MANAGEMENT
- Derisk on tapping resistance

"""

caa_2 = """

--------------------------------



RANGES

If BTC.D is ranging:

- Prefer longs on alts at range lows
- Don't open new positions on alts at range highs
- Vice versa for BTC & shorts

MANAGEMENT
- Derisk at rang highs/range lows.

"""