# code_strategy

All the files can be found in the download zip at the top right of the page, releases are outdated so if you do want the most recent one you'll have to download that.
