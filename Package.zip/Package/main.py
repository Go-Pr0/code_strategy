import os
import logging
from typing import Optional, Callable, List, Dict
from PyQt5 import QtWidgets, QtGui, QtCore
import txt
import qdarkstyle

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class MultiLayerQuestionsApp(QtWidgets.QWidget):
    # Constants for font sizes and margins
    FONT_SIZE_LAYER_LABEL = 9
    MARGIN_LAYER_LABEL = (20, 10, 20, 0)
    FONT_SIZE_QUESTION = 16
    MARGIN_QUESTION = (20, 5, 20, 0)
    FONT_SIZE_RESULT = 14
    MARGIN_RESULT = (20, 10, 20, 0)
    BUTTON_FONT_SIZE = 17
    OPTION_MARGIN = (20, 5, 20, 0)
    BUTTON_SPACER = (20, 5, 20, 5)
    IMAGE_SPACER_HEIGHT = 50

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Market Environments")
        self.setGeometry(100, 100, 1800, 1200)
        self.trend_context = None
        self.history_stack = []
        self.current_layer = 0
        self.init_ui()

    def init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # Scroll Area to hold content
        scroll_area = QtWidgets.QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scroll_content = QtWidgets.QWidget()
        self.scroll_layout = QtWidgets.QVBoxLayout(scroll_content)
        scroll_area.setWidget(scroll_content)

        # Layer label
        self.layer_label = QtWidgets.QLabel("Current Layer: 0")
        self.layer_label.setFont(QtGui.QFont("Arial", self.FONT_SIZE_LAYER_LABEL))
        self.layer_label.setAlignment(QtCore.Qt.AlignLeft)
        self.layer_label.setContentsMargins(*self.MARGIN_LAYER_LABEL)
        self.scroll_layout.addWidget(self.layer_label)

        # Question label
        self.question_label = QtWidgets.QLabel("Start the quiz")
        self.question_label.setFont(QtGui.QFont("Arial", self.FONT_SIZE_QUESTION))
        self.question_label.setAlignment(QtCore.Qt.AlignLeft)
        self.question_label.setContentsMargins(*self.MARGIN_QUESTION)
        self.scroll_layout.addWidget(self.question_label)

        # Option layout (for buttons)
        self.option_layout = QtWidgets.QHBoxLayout()
        self.option_layout.setContentsMargins(*self.OPTION_MARGIN)
        self.scroll_layout.addLayout(self.option_layout)

        # Result label
        self.result_label = QtWidgets.QLabel("")
        self.result_label.setFont(QtGui.QFont("Arial", self.FONT_SIZE_RESULT))
        self.result_label.setWordWrap(True)
        self.result_label.setAlignment(QtCore.Qt.AlignLeft)
        self.result_label.setContentsMargins(*self.MARGIN_RESULT)
        self.scroll_layout.addWidget(self.result_label)

        # Image layout
        self.setup_image_layout()

        layout.addWidget(scroll_area)

        # Reset and Exit buttons
        button_layout = QtWidgets.QHBoxLayout()
        button_layout.setContentsMargins(*self.BUTTON_SPACER)

        reset_button = QtWidgets.QPushButton("Back")
        reset_button.clicked.connect(self.reset)
        button_layout.addWidget(reset_button)

        exit_button = QtWidgets.QPushButton("Exit")
        exit_button.clicked.connect(self.exit_application)
        button_layout.addWidget(exit_button)

        layout.addLayout(button_layout)

        # Initialize first layer
        self.handle_answer(0, txt.x, [1, 2, 3], self.process_layer)

    def exit_application(self):
        logging.debug(f"Exiting application Error Code: 0")
        QtWidgets.qApp.quit()

    def setup_image_layout(self):
        image_layout = QtWidgets.QHBoxLayout()
        image_layout.setContentsMargins(0, 0, 0, 0)

        self.image_label = QtWidgets.QLabel("")
        self.image_label.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.image_label.setScaledContents(True)
        image_layout.addWidget(self.image_label)
        self.scroll_layout.addLayout(image_layout)

        # Add spacer below the image
        spacer = QtWidgets.QSpacerItem(20, self.IMAGE_SPACER_HEIGHT, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Fixed)
        self.scroll_layout.addSpacerItem(spacer)

    def handle_answer(self, layer: int, question_text: str, options: List[int], answer_callback: Callable):
        self.result_label.setText("")
        self.clear_image()

        self.current_layer = layer
        self.layer_label.setText(f"Current Layer: {layer}")
        self.question_label.setText(question_text)

        # Clear previous options
        for i in reversed(range(self.option_layout.count())):
            widget = self.option_layout.itemAt(i).widget()
            if widget:
                self.option_layout.removeWidget(widget)
                widget.deleteLater()

        # Create new option buttons
        for opt in options:
            btn = QtWidgets.QPushButton(str(opt))
            btn.setFont(QtGui.QFont("Arial", self.BUTTON_FONT_SIZE))
            btn.clicked.connect(lambda _, opt=opt: answer_callback(layer, opt))
            self.option_layout.addWidget(btn)

    def append_history(self, first: int, layer: int):
        entry = (first, layer)
        if not self.history_stack or self.history_stack[-1] != entry:
            self.history_stack.append(entry)
            logging.debug(f"History updated: {self.history_stack}")

    def reset(self):
        try:
            if not self.history_stack:
                self.current_layer = 0
                self.handle_answer(0, txt.x, [1, 2, 3], self.process_layer)
                self.result_label.setText("")
                self.clear_image()
                logging.debug("Reset to initial state: No history found.")
                return

            if self.history_stack[-1][1] == 1:
                self.history_stack.pop()
                if not self.history_stack:
                    self.current_layer = 0
                    self.handle_answer(0, txt.x, [1, 2, 3], self.process_layer)
                    self.history_stack = []  # Clear history stack
                    self.trend_context = None
                    logging.debug("Reset to initial state: History is now empty.")
                    return

            while self.history_stack and self.history_stack[-1][1] == 2:
                self.history_stack.pop()

            if self.history_stack:
                last_state = self.history_stack[-1]
                first = last_state[0]
                layer = self.current_layer - 1
                self.current_layer = layer
                if layer == 1:
                    self.restore_layer_1(first)
                elif layer == 0:
                    self.history_stack = []
                    self.handle_answer(0, txt.x, [1, 2, 3], self.process_layer)
                    self.trend_context = None
                    logging.debug("Reset to layer 0: History cleared.")
            else:
                self.current_layer = 0
                self.handle_answer(0, txt.x, [1, 2, 3], self.process_layer)
                self.history_stack = []
                self.trend_context = None
                logging.debug("Reset to layer 0: History cleared.")

            self.result_label.setText("")
            self.clear_image()
            logging.debug(f"History after reset: {self.history_stack}")
        except Exception as e:
            logging.error(f"Error during reset: {e}")
            QtWidgets.QMessageBox.critical(self, "Error", f"An error occurred: {e}")

    def process_layer(self, layer: int, answer: int):
        if not self.history_stack or self.history_stack[-1] != (1, layer):
            self.append_history(answer, layer)

        if layer == 0:
            if answer == 1:  # BTC
                self.trend_context = None
                self.handle_answer(1, txt.xx, [1, 2, 3, 4], self.process_layer_btc)
            elif answer == 2:  # TOTAL3
                self.trend_context = None
                self.handle_answer(1, txt.xx, [1, 2, 3, 4], self.process_layer_total3)
            elif answer == 3:  # BTC.D
                self.trend_context = None
                self.handle_answer(1, txt.xx_d, [1, 2, 3], self.process_layer_btcd)

    def restore_layer_1(self, first: int):
        if first == 1:
            self.handle_answer(1, txt.xx, [1, 2, 3, 4], self.process_layer_btc)
            logging.debug("Reset to Layer 1: BTC.")
        elif first == 2:
            self.handle_answer(1, txt.xx, [1, 2, 3, 4], self.process_layer_total3)
            logging.debug("Reset to Layer 1: TOTAL3.")
        elif first == 3:
            self.handle_answer(1, txt.xx_d, [1, 2, 3], self.process_layer_btcd)
            logging.debug("Reset to Layer 1: BTC.D.")

    def process_layer_btc(self, layer: int, answer: int):
        self.append_history(1, layer)
        if layer == 1:
            trend_map = {
                1: ('Uptrend', txt.a, [1, 2, 3, 4]),
                2: ('Downtrend', txt.ba, [1, 2, 3, 4, 5]),
                3: ('Ranges', txt.ca, [1, 2, 3]),
                4: ('Chop', txt.da, None)
            }
            trend_data = trend_map.get(answer)
            if trend_data:
                self.trend_context, question, options = trend_data
                if options:
                    self.handle_answer(2, question, options, self.process_layer_btc)
                else:
                    self.display_text(question, None)
        elif layer == 2:
            self.append_history(1, layer)
            action_map = {
                'Uptrend': {
                    1: (txt.aaa, "aaa.png"),
                    2: (txt.aab, "aab.png"),
                    3: (txt.aac, "aac.png"),
                    4: (txt.aae, "aae.png")
                },
                'Downtrend': {
                    1: (txt.baa, "baa.png"),
                    2: (txt.bab, "bab.png"),
                    3: (txt.bac, "bac.png"),
                    4: (txt.bad, "bad.png"),
                    5: (txt.bae, "bae.png")
                },
                'Ranges': {
                    1: (txt.caa, "caa.png"),
                    2: (txt.cab, "cab.png"),
                    3: (txt.cac, "cac.png")
                }
            }
            actions = action_map.get(self.trend_context, {})
            text_image = actions.get(answer)
            if text_image:
                self.display_text(*text_image)

    def process_layer_total3(self, layer: int, answer: int):
        self.append_history(2, layer)
        if layer == 1:
            trend_map = {
                1: ('Uptrend', txt.a, [1, 2, 3, 4]),
                2: ('Downtrend', txt.ba, [1, 2, 3, 4, 5]),
                3: ('Ranges', txt.ca, [1, 2, 3]),
                4: ('Chop', txt.da, None)
            }
            trend_data = trend_map.get(answer)
            if trend_data:
                self.trend_context, question, options = trend_data
                if options:
                    self.handle_answer(2, question, options, self.process_layer_total3)
                else:
                    self.display_text(question, None)
        elif layer == 2:
            self.append_history(2, layer)
            action_map = {
                'Uptrend': {
                    1: (txt.aaa_1, "aaa_1.png"),
                    2: (txt.aab_1, "aab_1.png"),
                    3: (txt.aac_1, "aac_1.png"),
                    4: (txt.aad_1, "aad_1.png")
                },
                'Downtrend': {
                    1: (txt.baa_1, "baa_1.png"),
                    2: (txt.bab_1, "bab_1.png"),
                    3: (txt.bac_1, "bac_1.png"),
                    4: (txt.bad_1, "bad_1.png"),
                    5: (txt.bae_1, "bae_1.png")
                },
                'Ranges': {
                    1: (txt.caa_1, "caa_1.png"),
                    2: (txt.cab_1, "cab_1.png"),
                    3: (txt.cac_1, "cac_1.png")
                }
            }
            actions = action_map.get(self.trend_context, {})
            text_image = actions.get(answer)
            if text_image:
                self.display_text(*text_image)

    def process_layer_btcd(self, layer: int, answer: int):
        self.append_history(3, layer)
        if layer == 1:
            trend_map = {
                1: ('Uptrend', txt.aaa_2, "aaa_2.png"),
                2: ('Downtrend', txt.baa_2, "baa_2.png"),
                3: ('Ranges', txt.caa_2, "caa_2.png")
            }
            trend_data = trend_map.get(answer)
            if trend_data:
                self.trend_context, text, image_name = trend_data
                self.display_text(text, image_name)

    def display_text(self, text: str, image_name: Optional[str]):
        self.result_label.setText(text)
        if image_name:
            scaled_pixmap = self.load_image(image_name)
            if scaled_pixmap:
                self.image_label.setPixmap(scaled_pixmap)
        else:
            self.clear_image()

    def load_image(self, image_name: str) -> Optional[QtGui.QPixmap]:
        if not image_name:
            return None

        base_dir = os.path.abspath(os.path.dirname(__file__))
        image_path = os.path.join(base_dir, "Pictures", image_name)

        if os.path.exists(image_path):
            pixmap = QtGui.QPixmap(image_path)
            max_width = self.width() - 20
            max_height = 1000
            scaled_pixmap = pixmap.scaled(
                max_width, max_height,
                QtCore.Qt.KeepAspectRatio,
                QtCore.Qt.SmoothTransformation
            )
            return scaled_pixmap
        else:
            QtWidgets.QMessageBox.critical(self, "Error", f"Image '{image_name}' not found at '{image_path}'")
            return None

    def clear_image(self):
        self.image_label.clear()

    def closeEvent(self, event: QtGui.QCloseEvent):
        logging.debug("Application is exiting. Goodbye!")
        event.accept()

if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    window = MultiLayerQuestionsApp()
    window.show()
    app.exec_()