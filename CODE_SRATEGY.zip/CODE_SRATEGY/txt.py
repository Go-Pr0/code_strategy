#================================================================================================#
#QUESTIONS
#================================================================================================#
xx = """
MARKET ENVIRONMENTS

Uptrend (1)
Downtrend (2)
Range (3)
Chop (4)

"""

xx_d = """
MARKET ENVIRONMENTS

Uptrend (1)
Downtrend (2)
Range (3)

"""

x = """
MARKETS

BTC (1)
TOTAL3 (2)
ALT DOM (3)

"""

a = """
Regular Uptrend (1)
Late (2) -> Parabolica
Structural Buying (3)
HTF breakout (4)

"""

ba = """
Downtrend (1)
Late downtrend (2) -> very far from ATHs + heavily shorted already
Post Nuke (3) -> Big gap in price and 4H trend after massive nuke
Structural Selling (4)
HTF breakdown (5)

"""

ca = """
Accumelation ranges (1) -> base building
Distribution ranges (2) -> rounded top/bottom range magnet
Ranges (3) -> Regular old range

"""

#--



#================================================================================================#
#ENDS
#================================================================================================#

# UPTRENDS
# BTC

aaa = """ 

--------------------------------



UPTRENDS

Considering this is a regular uptrend, in a larger range or not:
- Take positions via 4H 200s or other confluence factors (long if not near resistance)
- Use ALT/BTC charts to judge relative strength 
- Use 1-BTC.D to judge whether BTC will have a higher probability of outperforming alts
  (if so, focus on BTC ofc)

MANAGEMENT:
- Judge how to TP according to past trends (see BTC May-June vs July - October, both 
  in the same range yet one scenario allows for full targets)

"""

aab = """ 

--------------------------------



LATE UPTRENDS

Indicator of a late uptrend:
- Large gap between:
    - 4H trend
    - D1 trend
- Inverted chart = straigth down, nuke

MANAGEMENT
- Derisk as we approach HTF resistance
- Derisk positions on 4H trend losses, this is parabolica ssn and it can't last

"""

aac = """

--------------------------------



STRUCTURAL BUYING

This often traps a lot of ppl, especially structured buying into resistance this 
is also known as vertical consolidation. (usually)

- Post nuke = buy (bottoming pattern)
- Near new highs/euphoric ssn = evaluate if there is still upside to be caught bc
  most ppl will be long anyway
- Look at context, strucural selling can be confused with an unsustainable grind
  up, make sure to know what it is you're looking at.

MANAGEMENT:
- Target nearest S/R level/gapfill into 4H 200s
- Expect a squeeze/ - even bigger squeeze on strong alt

"""

aae = """

--------------------------------



HTF BREAKOUTS

- Size big on 4H trend retests because most people will be sidelined and not ready to enter with 
  conviction. If you enter later, you will get chopped up once the first real range forms
- Be very conservative in TP'ing positions, allow yourself to stretch targets towards HTF levels

MANAGEMENT:
- Extend targets

"""

#DOWNTRENDS

baa = """

--------------------------------



DOWNTRENDS

Indications of a downtrend:
- 4H trend+S/R retests if you're early for a breakdown.
- Swing short positions via 4H 200s / higher timeframe EMA's

MANAGEMENT:
- TP HTF levels

"""

bab = """

--------------------------------



LATE DOWNTRENDS

Indicator of a late downtrend:
- Large gap between:
    - 4H trend
    - D1 trend
- Inverted chart = parabolica

- Prefer not taking new shorts if possible
- If the setup is too good not to take, TP quickly
- Don't fall for free shorts, no such thing (compression into resistance)

MANAGEMENT:
- Derisk swing short positions on taps of HTF support/changes in the trend

"""

bac = """

--------------------------------



POST NUKE

Look for gaps in price and EMA's
post-nuke plays often take days to form, hours to play out.

- Mean reversion plays via:
    Bottoming patterns
    Reclaims of key levels
    Bullish market structures - higher lows after continued lower lows
    Reclaims of moving averages

MANAGEMENT:
- Prepare for quick moves, worst thing that happens post nuke is getting
  chopped up (95% of cases)
- Exit position if it doesn't go anywhere
(more examples in specific document)

"""

bad = """

--------------------------------



STRUCTURAL SELLING

Usually, you don't wnat to long this PA, structural selling often ends in
a final flush down before going back up.

- Don't take longs into this if you can avoid it
- Look at context, structural selling post nuke is different than mid range

MANAGEMENT:
- Derisk longs if you have them still open

"""

bae = """

--------------------------------



HTF BREAKDOWN

This usually folllows after a distribution range, when the the coin you're 
trading allows for it:
- Take swing short positions alongside 4H 200s
- Check ALT/BTC charts to check for relative performance
- Don't short BTC, instead prefer shorting weak alts

MANAGEMENT:
- Close any and all longs (entered new phase : bear market)
- Extend targets on shorts

"""

#RANGES

caa = """

--------------------------------



ACCUMULATION RANGES

- Use range highs/lows on BTC to long or short alts (if aligned with BTC). 
  After a deviation, place orders at the range highs/lows. (prefer longs)
- Usually lots of compression into the lows before a run to get people at
  max pain
- Look for strong coins to long

"""

cab = """

--------------------------------



DISTRIBUTION RANGES

- Use range highs/lows on BTC to long or short alts (if aligned with BTC). 
  After a deviation, place orders at the range highs/lows. (prefer shorts)
- Usually comes in the form of a rounded top with 1 or 2 topside deviations

"""

cac = """

--------------------------------



RANGES

- Use range highs/lows on BTC to long or short alts (if aligned with BTC). 
  After a deviation, place orders at the range highs/lows. 
- Prefer whichever way the past trend was trending if there was one when 
  taking positions but don't limit yourself to it.

"""

#CHOPS

da = """

--------------------------------



CHOP

No trades, study past PA and prepare for upcoming/anticipated moves later on.

"""

#================================================================#
#TOTAL3
#================================================================#

aaa_1 = """

--------------------------------



UPTRENDS

Considering this is a regular uptrend, in a larger range or not:
- If this has put in a real trend, expect it to hold 4H trend at all times, this
  chart is one of the few ones that trade cleanly.
- If deeper pullback to 4H 200s, long it in most cases.

MANAGEMENT:
- TP positions on alts according to HTF resistance on this chart, same for support
! Doesn't mean you should ALWAYS using this chart, example:

  ALT uptrend + broken out from a large range, TOTAL3 straight down causing that alt
  to retrace, should u not long just bc total3 is downtrending? No, expect a bounce
  and play it on that outperforming alt.

"""

aab_1 = """

--------------------------------



LATE UPTRENDS

Indicator of a late uptrend:
- Large gap between:
    - 4H trend
    - D1 trend
- Inverted chart = straigth down, nuke

MANAGEMENT
- Derisk as we approach HTF resistance, image = prime example
- Derisk positions on 4H trend losses, this is parabolica ssn and it can't last

"""

aac_1 = """

--------------------------------



STRUCTURAL BUYING

This often traps a lot of ppl, especially structured buying into resistance this 
is also known as vertical consolidation. (usually)

- Post nuke = buy (bottoming pattern)
- Heavily shorted coin = buy
- Near new highs/euphoric ssn = evaluate if there is still upside to be caught bc
  most ppl will be long anyway

MANAGEMENT:
- Target nearest S/R level/gapfill into 4H 200s
- Expect a squeeze/ - even bigger squeeze on strong alt
  
"""

aad_1 = """

--------------------------------



HTF BREAKOUTS

- Size big early on 4H trend retests/consolidations. (no need for 4H 200s retests -> weak breakout)
- Be very conservative in TP'ing positions, allow yourself to stretch targets towards HTF levels

MANAGEMENT:
- Extend targets

"""

#DOWNTRENDS
baa_1 = """

--------------------------------



DOWNTRENDS

Look for underperformance via ALT/BTC charts + regular charts
- 4H trend+S/R retests if you're early for a breakdown.
- Swing short positions via 4H 200s / higher timeframe EMA's
- Look for bounces at obvious support - long outperformers who are still above their
  4H 200s (if you expect a pullback)

MANAGEMENT:
- TP HTF levels on TOTAL3/BTC

"""

bab_1 = """

--------------------------------



LATE DOWNTRENDS

Indicator of late downtrend:
- Large gap between:
    - 4H trend
    - D1 trend
- Inverted chart = parabolica

- Prefer not taking new shorts if possible
- If the setup is too good not to take, TP quickly
- Don't fall for free shorts, no such thing (compression into resistance)

MANAGEMENT:
- Derisk swing short positions on taps of HTF support/changes in the trend 

"""

bac_1 = """

--------------------------------



POST NUKE

Look for gaps in price and EMA's
post-nuke plays often take days to form, hours to play out.

- Mean reversion plays via:
    Bottoming patterns
    Reclaims of key levels
    Bullish market structures - higher lows after continued lower lows
    Reclaims of moving averages

MANAGEMENT:
- Prepare for quick moves, worst thing that happens post nuke is getting
  chopped up (95% of cases)
- Exit position if it doesn't go anywhere
(more examples in specific document)

"""

bad_1 = """

--------------------------------



STRUCTURAL SELLING

Usually, you don't wnat to long this PA, structural selling often ends in
a final flush down before going back up.

- Don't take longs into this if you can avoid it
- Look at context, structural selling post nuke is different than mid range

MANAGEMENT:
- Derisk longs if you have them still open

"""

bae_1 = """

--------------------------------



HTF BREAKDOWN

This usually folllows after a distribution range, when the the coin you're 
trading allows for it:
- Take swing short positions alongside 4H 200s/levels on TOTAL3
- Check where BTC is trading, this might be a leverage flush out

MANAGEMENT:
- Close any and all longs (entered new phase : altcoin bear market)
- Apart from local levels, use TOTAL3 HTF levels to TP -> plan in advance

"""

#RANGES
caa_1 = """

--------------------------------



ACCUMULATION RANGES

- Use range highs/lows on TOTAL3 to long or short alts (if aligned with BTC too). 
  After a deviation, place orders at the range highs/lows. (prefer shorts)
- Reversals in the previous trend usually come as a rounded bottom with 1 or 2 
  deviations

"""

cab_1 = """

--------------------------------



DISTRIBUTION RANGES

- Use range highs/lows on TOTAL3 to long or short alts (if aligned with BTC too). 
  After a deviation, place orders at the range highs/lows. (prefer shorts)
- Reversals in the previous trend usually come as a rounded top with 1 or 2 
  deviations while price struggles/fails to even reach range highs

"""

cac_1 = """

--------------------------------



RANGES

- Use range highs/lows on TOTAL3 to long or short alts that are probable to 
  underperform. 
- After a deviation, place orders at the range highs/lows. 
- Prefer whichever way the past trend was trending if there was one when 
  taking positions but don't limit yourself to it.

! Total3 trades relatively clean so deviations are very playable  

"""

# BTC DOM

aaa_2 = """

--------------------------------



UPTRENDS

Considering that you're in a real uptrend, you can expect a real cycle of alts 
outperforming btc.

- Long outperforming alts
(Most alts)
- Long pullbacks into 4H trend

MANAGEMENT:
- Derisk when parabolic and nearing HTF support
(But make sure not to close too soon, btc.d runs are often straight up all the way not caring about resistance)

"""

baa_2 = """

--------------------------------



DOWNTRENDS

If you're still in in the massive downtrend BTC.D is currently in:

- Long on pullbacks into a higher timeframe trend post nuke (gapfills)
- Long BTC post gapfill (considering you're uptrending on BTC and have a setup)

MANAGEMENT:
- Derisk on tapping resistance

"""

caa_2 = """

--------------------------------



RANGES

If BTC.D is ranging:

- Prefer longs on alts at range lows
- Don't open new positions on alts at range highs
- Vice versa for BTC & shorts

MANAGEMENT:
- Derisk at rang highs/range lows.

"""